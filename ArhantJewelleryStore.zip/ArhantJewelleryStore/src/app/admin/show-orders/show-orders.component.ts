import { Component } from '@angular/core';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-show-orders',
  templateUrl: './show-orders.component.html',
  styleUrl: './show-orders.component.css'
})
export class ShowOrdersComponent {
  orders: any;
 
  constructor(private auth: AdminServiceService) { }
 
  ngOnInit(): void {
    this.getOrders();
  }
 
  getOrders(): void {
    this.auth.getAllOrders().subscribe({
      next:
      (orders) => {
        this.orders = orders;
      },
      error:(error) => {
        console.error('Error fetching orders:', error);
      }
  });
  }
}