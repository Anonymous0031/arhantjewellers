// his function is responsible for bootstrapping the Angular application.
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';


platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));


  //This code is the entry point for the Angular application. 
  //It creates the browser platform and bootstraps the root module (AppModule), 
  //which then initializes the entire application. The error handling ensures that any 
  //issues during the bootstrapping process are properly logged for debugging purposes.