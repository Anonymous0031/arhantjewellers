﻿using ArhantJewellers.Entities.Dto.ProductDto;

namespace ArhantJewellers.Entities.Dto.CategoryDto
{
    public class CategoryDto
    {
        public int Id { get; set; }
        public string CategoryName { get; set; }
        public List<ResponseProductDto> Products { get; set; }
    }
}
