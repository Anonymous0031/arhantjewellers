﻿using Microsoft.AspNetCore.Mvc;
using ArhantJewellers.Entities.Dto.CategoryDto;
using ArhantJewellers.Entities.Dto.OrdersDto;
using ArhantJewellers.Entities.Dto.ProductDto;
using ArhantJewellers.Entities.Dto.UserDto;
using ArhantJewellers.Entities.Models;

namespace ArhantJewellers.Repository.Interfaces
{
    public interface IUserRepository
    {

        Task<RegisterUserDto> Register(RegisterUserDto registeruserdto);

        Task<string> Login(LoginUserDto loginUserDto);

        Task<IEnumerable<ResponseProductDto>> GetAllProducts();
        Task<IEnumerable<ResponseProductDto>> GetProductsByCategory(int categoryId);
        Task<List<CategoryDto>> GetCategories();
        Task<IEnumerable<ResponseProductDto>> SearchByBrand(string brandName);
        Task<RegisterUserDto> UpdateUser(int Id, RegisterUserDto user);
        Task<string> CheckOut(string userEmail);
        Task<IEnumerable<OrderItemDto>> GetOrdersByUserId(string userEmail);


    }
}
