﻿using AutoMapper;
using ArhantJewellers.Entities.Dto.AdminDto;
using ArhantJewellers.Entities.Dto.CartItemDto;
using ArhantJewellers.Entities.Dto.CategoryDto;
using ArhantJewellers.Entities.Dto.ProductDto;
using ArhantJewellers.Entities.Dto.UserDto;
using ArhantJewellers.Entities.Models;

namespace ArhantJewellers.Map
{
    public class ApplicationMapper : Profile   //The Profile class is a base class that allows you to configure your mapping rules.
    {
        public ApplicationMapper()
        {
            CreateMap<User, RegisterUserDto>().ReverseMap();
            CreateMap<User, LoginUserDto>().ReverseMap();
            CreateMap<Admin, LoginAdminDto>().ReverseMap();
            CreateMap<Admin, RegisterAdminDto>().ReverseMap();
            CreateMap<Product, RequestProductDto>().ReverseMap();
            CreateMap<Product, ResponseProductDto>().ReverseMap();
            CreateMap<Category, CategoryDto>().ReverseMap();
            CreateMap<Category, AddCategoryDto>().ReverseMap();
            CreateMap<CartItem, CartItemDto>().ReverseMap();

        }

    }
}
